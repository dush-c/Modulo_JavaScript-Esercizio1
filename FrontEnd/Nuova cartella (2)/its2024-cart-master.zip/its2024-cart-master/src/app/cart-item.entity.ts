export interface  CartItem {
  id: number;
  name: string;
  netPrice: number;
  weight: number;
  discount: number;
  quantity: number;
}
